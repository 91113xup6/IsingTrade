A Pen created at CodePen.io. You can find this one at http://codepen.io/m412c0/pen/Fybpf.

 Inspired by http://dribbble.com/shots/975425-Flat-UI-login